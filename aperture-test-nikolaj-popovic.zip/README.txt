This is the test done by Nikolaj Popovic applied for position Web Developer.

For this HTML page building I used Bootstrap 5 library when building this html page as per https://www.notion.so/Aperture-HTML-Interview-Question-Public-ada402cd3dc542cebcf2dee0de55f8a3

Please review.

It's responsive on mobile devices and on Desktop.

Regards,
Nikolaj